---
name: branded-deck
description: Use this skill whenever the user asks for a slide deck, pitch deck, sales deck, internal presentation, PowerPoint, Google Slides export, or any "make slides for me" request. Triggers on words like "deck", "slides", "presentation", "PPT", "PowerPoint", "pitch", "executive summary deck". Produces an on-brand, Apple-clean slide deck (.pptx) that follows the project's visual identity.
---

# Branded Deck Skill

You are creating a **branded slide deck** for this project. The deck must look polished, modern, and Apple-inspired — clean type, generous whitespace, one idea per slide.

---

## Step 1 — Read the Brand Context (Required)

Before drafting any slide, read these two files:

1. `brand/brand-context.md` — for voice, audience, positioning
2. `brand/visual-identity.md` — for colors, fonts, layout rules

If either file is missing or empty, **ask the user to fill them in first**. Do not invent brand details.

---

## Step 2 — Clarify the Request

Ask the user (in one short message) for whatever is missing:

- **Audience** — who is this deck for? (e.g., investor, customer, internal team)
- **Purpose** — what should the audience do or believe after seeing it?
- **Length** — how many slides? (default: 8–10 if not specified)
- **Format** — `.pptx` (default), Google Slides, or PDF export

If the user has already given these in their request, skip the question and proceed.

---

## Step 3 — Build the Outline First

**Always show a slide-by-slide outline before producing the full deck.** Wait for the user's approval (a 👍 or "looks good") before generating the actual file.

Use this default structure unless the user asks for something different:

| # | Slide | Purpose |
|---|---|---|
| 1 | Title | Headline + subhead + brand mark |
| 2 | The problem | One sharp observation about the audience's pain |
| 3 | Why now | The shift or trigger that makes this urgent |
| 4 | The solution | What you offer, in one sentence |
| 5 | How it works | 3 steps or 3 pillars, max |
| 6 | Proof | 1–3 stats, customer logos, or quotes |
| 7 | Differentiator | The single reason to pick you |
| 8 | The ask / next step | Clear call to action |

---

## Step 4 — Draft the Slides

Follow these rules on every slide:

- **One idea per slide.** If you have two, split them.
- **Title under 6 words.** Body under 30 words.
- **Use the brand palette.** Pull hex codes from `brand/visual-identity.md`. Never invent colors.
- **Use the brand fonts.** No exceptions.
- **Whitespace is your friend.** Aim for 40–60% empty space per slide.
- **Highlight one number or phrase per slide** in the accent color.
- **No clip art.** No stock-photo handshakes. No drop shadows on flat designs.

---

## Step 5 — Generate the File

Use the public `pptx` skill to render the actual `.pptx` file. Save the output to:

```
campaigns/[campaign-name]/deck-[YYYY-MM-DD].pptx
```

Then copy the final approved version to `outputs/`.

---

## Step 6 — Self-Check Before Delivering

Before showing the deck to the user, run through this quick checklist:

- [ ] Every slide title is ≤ 6 words
- [ ] Every slide body is ≤ 30 words
- [ ] Colors match the brand palette exactly
- [ ] Fonts match the brand typography exactly
- [ ] No clichés ("revolutionary", "synergy", "in today's fast-paced world")
- [ ] One clear takeaway per slide
- [ ] CTA is on the last slide and is specific

If any item fails, fix it before delivering.

---

## Output Format

When you deliver the deck, include in the chat:

1. The file path of the saved `.pptx`
2. A 3-bullet summary of the deck's argument
3. One suggestion for what the user might want to refine next

Keep the chat reply short — the deck is the deliverable, not the message.
