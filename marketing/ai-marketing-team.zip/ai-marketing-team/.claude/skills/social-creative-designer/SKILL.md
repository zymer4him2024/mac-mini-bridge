---
name: social-creative-designer
description: Use this skill when the user asks for a social media graphic, ad creative, post visual, banner, thumbnail, or any image meant to live on LinkedIn, X (Twitter), Instagram, Facebook, YouTube, or TikTok. Triggers on words like "social post", "creative", "ad image", "banner", "thumbnail", "feed graphic", "story", "carousel". Produces on-brand visuals that match the project's visual identity.
---

# Social Creative Designer Skill

You are creating a **social media visual** for this project. The output must be on-brand, platform-appropriate, and stop-the-scroll worthy without ever feeling like generic AI art.

---

## Step 1 — Read the Brand Context (Required)

Before drafting any visual, read:

1. `brand/brand-context.md` — for tone, audience, positioning
2. `brand/visual-identity.md` — for colors, fonts, imagery rules

If either is missing, ask the user to fill them in first.

---

## Step 2 — Get the Three Things You Need

Confirm with the user (in one short message) before designing:

- **Platform** — LinkedIn / Instagram / X / YouTube thumbnail / Facebook / TikTok
- **Format** — single image, carousel (how many slides?), story, banner, ad
- **Message** — the one thing the viewer should take away

If the user already gave these, skip the question.

---

## Step 3 — Pick the Right Dimensions

Use these defaults unless the user asks for custom:

| Platform | Format | Dimensions (px) |
|---|---|---|
| LinkedIn | Feed image (square) | 1200 × 1200 |
| LinkedIn | Carousel slide | 1080 × 1080 |
| Instagram | Feed (square) | 1080 × 1080 |
| Instagram | Reel cover / Story | 1080 × 1920 |
| X (Twitter) | In-feed image | 1600 × 900 |
| YouTube | Thumbnail | 1280 × 720 |
| Facebook | Feed image | 1200 × 630 |
| TikTok | Cover | 1080 × 1920 |

---

## Step 4 — Apply the Design Rules

Every visual follows these rules — no exceptions:

**Composition**
- One focal point. Eye lands in one place first.
- Headline must be readable on a phone at thumb-distance — usually 60–90 pt for square feed posts.
- Generous whitespace. Aim for 40% of the canvas empty.
- Use a clear visual hierarchy: headline > subhead > supporting detail > brand mark.

**Color**
- Pull hex codes from `brand/visual-identity.md`. Never invent colors.
- Use one accent color per visual to highlight the key word or number.
- Backgrounds: prefer solid brand neutrals over gradients.

**Type**
- Use the brand fonts only.
- Headline ≤ 8 words.
- No more than 2 fonts in one design (one for headline, one for body).

**Imagery**
- Real photos > stock > illustration > emoji.
- No drop shadows on flat designs.
- No clip-art, no fake-AI 3D renders, no people pointing at laptops.

---

## Step 5 — Draft the Copy First, Then the Visual

1. Write the headline (≤ 8 words).
2. Write the supporting line (≤ 15 words).
3. Decide the focal element (number, photo, icon, or pure type).
4. *Then* design.

Show this copy to the user before rendering — small text changes save big design rework.

---

## Step 6 — Render the Visual

Use the available image-generation tool or HTML/SVG output to produce the visual at the correct dimensions.

Save to:

```
campaigns/[campaign-name]/social/[platform]-[format]-[YYYY-MM-DD].png
```

For carousels, save each slide as a numbered file: `slide-01.png`, `slide-02.png`, etc.

---

## Step 7 — Self-Check Before Delivering

- [ ] Dimensions match the platform exactly
- [ ] Headline is readable on a phone screen
- [ ] Colors and fonts match the brand
- [ ] One clear focal point
- [ ] Brand mark is present and not stretched
- [ ] No copy clichés
- [ ] CTA (if any) is unambiguous

---

## Output Format

When you deliver, include in the chat:

1. The file path(s)
2. The headline + supporting line as plain text (so the user can copy them into the post caption)
3. A suggested 1–2 sentence caption for the platform
4. One alternative version idea the user could try (e.g., "Want to see this in dark mode?")
