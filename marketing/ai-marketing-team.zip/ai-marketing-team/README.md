# AI Marketing Team — Project README

This folder turns Claude Code into a small, on-brand marketing team. It follows the structure from Grace Leung's "Build Your Full AI Marketing Team" tutorial.

---

## Folder Structure

```
ai-marketing-team/
├── CLAUDE.md                              ← Project context + agent routing rules
├── README.md                              ← You are here
│
├── brand/
│   ├── brand-context.md                   ← Voice, audience, positioning
│   └── visual-identity.md                 ← Colors, fonts, layout rules
│
├── .claude/
│   ├── skills/
│   │   ├── branded-deck/
│   │   │   └── SKILL.md                   ← Skill #1: makes branded slide decks
│   │   └── social-creative-designer/
│   │       └── SKILL.md                   ← Skill #2: makes social media visuals
│   └── agents/
│       ├── data-analyst.md                ← Agent #1: handles all numbers
│       └── content-creator.md             ← Agent #2: handles all copy
│
├── campaigns/                             ← One subfolder per active campaign
└── outputs/                               ← Final, approved deliverables
```

---

## How to Use It (3 Steps)

### Step 1 — Fill in your brand

Open `brand/brand-context.md` and `brand/visual-identity.md` and replace every `[bracketed placeholder]` with your real brand details.

> **Tip:** Don't skip this. Every agent and skill reads these files before producing output. Garbage in = garbage out.

### Step 2 — Open the project in Claude Code

In your terminal, navigate to this folder and run:

```bash
cd ai-marketing-team
claude
```

Claude Code will automatically read `CLAUDE.md` and load your skills and agents. Confirm they loaded by typing:

```
/agents
```

You should see `data-analyst` and `content-creator` listed. Then:

```
/skills
```

You should see `branded-deck` and `social-creative-designer` listed.

### Step 3 — Talk to the team

Try any of these:

- *"Use the content-creator agent to draft a LinkedIn post announcing our new feature."*
- *"Have the data-analyst look at this CSV and tell me what's working."*
- *"Use the branded-deck skill to make a 6-slide overview of our Q2 strategy."*
- *"Design a social creative for the campaign launch using the social-creative-designer skill."*
- *"Launch a full campaign for [Product X]."* → triggers the multi-step orchestration in `CLAUDE.md`

---

## When to Edit Each File

| File | Edit when... |
|---|---|
| `CLAUDE.md` | You add a new agent or skill, or change the routing logic |
| `brand/brand-context.md` | Your voice, audience, or positioning evolves |
| `brand/visual-identity.md` | You rebrand or update colors/fonts |
| `.claude/skills/*/SKILL.md` | You want the skill to behave differently |
| `.claude/agents/*.md` | You want the agent to behave differently |

---

## Tips for a Non-Engineer

- Every file is plain English markdown. **You can edit it like a Google Doc.**
- If something feels wrong, edit the relevant `.md` file and tell Claude *"reload the project"*. No code changes needed.
- Keep `CLAUDE.md` short — long routing files confuse the team. Aim for one screen.
- Treat `brand/brand-context.md` as a living document. The better it is, the better every output gets.

---

## What's Next (Optional Upgrades)

When you're comfortable, you can extend the team by:

1. Adding a **`seo-strategist`** agent for keyword research and on-page optimization
2. Adding a **`brand-deck-templates`** folder with reusable slide layouts
3. Connecting a **Notion task board** so agents pick up work autonomously (covered at 13:53 in the video)
4. Setting up **remote control** to send tasks from your phone (covered at 15:17 in the video)

Add new agents to `.claude/agents/` and new skills to `.claude/skills/`. Update `CLAUDE.md` so the team knows when to route to them.
