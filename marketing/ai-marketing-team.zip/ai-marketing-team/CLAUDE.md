# CLAUDE.md — AI Marketing Team

> This file is read automatically by Claude Code every time you open this project in your terminal.
> Treat it as the "front desk" of your AI marketing team — it tells Claude **who is on the team, what they do, and which one to route a request to.**

---

## 1. Project Overview

This project is an **AI marketing team** that runs inside Claude Code. It contains:

- **2 Skills** — reusable, branded workflows (Branded Deck, Social Creative Designer)
- **2 Agents** — specialized team members with their own context (Data Analyst, Content Creator)
- **Brand context** — the single source of truth for tone, audience, colors, and positioning

The goal: **delegate marketing tasks** (research, content, decks, analytics) to the right specialist, and get on-brand outputs every time.

---

## 2. How to Talk to the Team

When the user gives a request, follow this routing logic **before doing the work yourself**:

| If the request is about... | Route to... |
|---|---|
| Numbers, KPIs, dashboards, campaign performance, A/B tests, weekly reports | **`data-analyst`** agent |
| Blog posts, social posts, email copy, captions, landing page copy, scripts | **`content-creator`** agent |
| A pitch deck, sales deck, internal slides, branded PowerPoint | **`branded-deck`** skill |
| A social media graphic, ad creative, banner, thumbnail | **`social-creative-designer`** skill |
| A full campaign launch (deck + social + email + analytics plan) | **Orchestrate**: call agents/skills in sequence (see §4) |

If the request is unclear, **ask one short clarifying question** before routing.

---

## 3. Brand Context (Always Apply)

Every output **must** match the brand guidelines in:

- `brand/brand-context.md` — voice, audience, positioning
- `brand/visual-identity.md` — colors, fonts, logo rules

Before any deliverable, **read both files** so the agent or skill produces on-brand work. Do not invent brand details that aren't in those files — if something is missing, flag it to the user.

---

## 4. Team Orchestration (Multi-Step Campaigns)

When the user says something like *"launch a campaign for [X]"* or *"build a full content package"*, run this sequence:

1. **Data Analyst** → pull baseline numbers, audience insights, past performance
2. **Content Creator** → draft copy (blog + social + email) using those insights
3. **Social Creative Designer** (skill) → create visuals to match the copy
4. **Branded Deck** (skill) → assemble a one-page launch summary or pitch deck
5. **Data Analyst** → define how success will be measured (KPIs, tracking)

Always show the user the plan first. Wait for a 👍 before kicking off the full sequence.

---

## 5. Working Folders

| Folder | Use for |
|---|---|
| `brand/` | Voice, audience, visual identity (read-only context) |
| `campaigns/` | One subfolder per active campaign (drafts, briefs, outputs) |
| `outputs/` | Final deliverables ready to share or publish |
| `.claude/skills/` | Reusable skills (do not edit during a task — only when refining the system) |
| `.claude/agents/` | Agent definitions (same rule as skills) |

When you create a new deliverable, save it under `campaigns/[campaign-name]/` first, then copy the final version to `outputs/`.

---

## 6. House Rules

- **Brand first.** Every piece of output is checked against `brand/brand-context.md`.
- **Plain language.** Explain choices in simple, non-technical English — assume the user is a busy executive, not an engineer.
- **One step at a time.** For long tasks, show progress between steps so the user can correct course early.
- **Ask, don't assume.** If a key fact is missing (target audience, deadline, channel), ask before drafting.
- **No fake data.** If you don't have real numbers, say so — never fabricate analytics.

---

## 7. Quick Commands the User May Type

- *"Run the content creator for a LinkedIn post about [topic]"* → invoke `content-creator` agent
- *"Use the branded deck skill to make a 5-slide overview of [topic]"* → invoke `branded-deck` skill
- *"Have the data analyst look at this CSV"* → invoke `data-analyst` agent with the file
- *"Design a social creative for [campaign]"* → invoke `social-creative-designer` skill
- *"Launch a campaign for [product]"* → run the full orchestration in §4
