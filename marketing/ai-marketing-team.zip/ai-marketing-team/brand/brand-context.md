# Brand Context

> **What this file is for:** This is the single source of truth for *who the brand is and how it speaks*. Every agent and skill in this project reads this before producing output.
>
> **How to use it:** Replace the placeholder text in [brackets] with your real brand details. Keep it short — under one page is ideal.

---

## 1. Brand Snapshot

- **Brand name:** [Your Brand Name]
- **One-line positioning:** [What you do, for whom, and why it matters — in one sentence]
- **Mission:** [The change you exist to create]
- **Founded / based in:** [Year, city]

---

## 2. Audience

**Primary audience**

- **Who they are:** [Job title / role / life stage]
- **What they care about:** [Top 3 priorities or pain points]
- **Where they spend time online:** [LinkedIn, X, Instagram, YouTube, niche communities]

**Secondary audience**

- [Same three bullets for the next-most-important group]

---

## 3. Voice & Tone

**Voice (always true)**

- [Adjective 1] — e.g., *clear*
- [Adjective 2] — e.g., *confident*
- [Adjective 3] — e.g., *warm but never fluffy*

**Tone (varies by context)**

| Context | Tone |
|---|---|
| LinkedIn thought leadership | Insightful, first-person, generous with takeaways |
| Product launch | Confident, specific, benefit-led |
| Customer support reply | Calm, direct, problem-solving |
| Internal/exec deck | Crisp, data-led, no hype |

---

## 4. Words We Use vs. Words We Avoid

**Use**

- [e.g., "platform", "build", "real outcomes"]

**Avoid**

- [e.g., "synergy", "revolutionary", "game-changer", emoji-heavy openings]

---

## 5. Signature Patterns

These are the small habits that make our writing feel like *us*:

- Open with a concrete observation, not a definition.
- One idea per sentence.
- End thought-leadership posts with a question or a clear next step.
- Never start a paragraph with "In today's fast-paced world…".

---

## 6. Proof Points (Use to Add Credibility)

Pull from this list when you need a stat, customer quote, or example:

- [Stat or milestone #1 — e.g., "Trusted by 500+ teams in 30 countries"]
- [Customer quote #1]
- [Notable partner / certification / award]

---

## 7. What We Do **Not** Do

- We don't write generic AI-sounding intros.
- We don't make up customer quotes or numbers.
- We don't speak for competitors.
- We don't use clickbait headlines.
