# Visual Identity

> **What this file is for:** Anytime an agent or skill creates a visual (deck, social graphic, banner, thumbnail), it reads this file to stay on-brand.
>
> **How to use it:** Replace placeholders with your real values. Keep hex codes and font names exact.

---

## 1. Color Palette

### Primary

| Name | Hex | Use for |
|---|---|---|
| [Primary 1] | `#000000` | Main brand color, headlines, CTAs |
| [Primary 2] | `#FFFFFF` | Backgrounds, negative space |

### Accent

| Name | Hex | Use for |
|---|---|---|
| [Accent 1] | `#0A84FF` | Links, highlights, key data points |
| [Accent 2] | `#34C759` | Positive metrics, success states |
| [Accent 3] | `#FF453A` | Warnings, declines (use sparingly) |

### Neutral

| Name | Hex | Use for |
|---|---|---|
| Charcoal | `#1C1C1E` | Body text |
| Gray 1 | `#8E8E93` | Secondary text |
| Gray 2 | `#E5E5EA` | Dividers, card backgrounds |

---

## 2. Typography

| Use | Font | Weight | Size guide |
|---|---|---|---|
| Headlines (H1) | [e.g., Inter] | Bold (700) | 32–48 pt |
| Subheads (H2) | [e.g., Inter] | Semibold (600) | 20–28 pt |
| Body | [e.g., Inter] | Regular (400) | 14–16 pt |
| Captions / metadata | [e.g., Inter] | Medium (500) | 11–12 pt |

**Web-safe fallback:** `system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`

---

## 3. Logo Rules

- **Clear space:** Minimum padding around the logo equals the height of the logo's "x" character.
- **Minimum size:** [e.g., 24 px tall on screen, 0.5 inch in print]
- **Don't:** stretch, recolor, add drop shadows, place on busy backgrounds, or rotate the logo.
- **Files to use:** `brand/logo-light.svg` (for dark backgrounds), `brand/logo-dark.svg` (for light backgrounds).

---

## 4. Layout Principles

The aesthetic is **clean, modern, Apple-inspired**:

- Generous whitespace — let the content breathe.
- One focal point per slide or post.
- Avoid more than 2 fonts and 3 colors in a single visual.
- Align everything to a clear grid.
- Rounded corners (8–16 px radius) on cards and buttons.

---

## 5. Imagery Style

- **Photography:** Bright, natural light. Real people over stock when possible.
- **Illustration:** Minimal line art or flat geometric shapes. No clip-art, no 3D AI-rendered fluff.
- **Icons:** Use a single icon library (e.g., [Lucide], [Heroicons], or [SF Symbols]). Don't mix styles.
- **Charts:** Match the brand palette. Highlight one data point in an accent color; keep everything else neutral.

---

## 6. Don'ts (Quick Checklist)

- ❌ No drop shadows on flat designs
- ❌ No gradient backgrounds unless explicitly approved
- ❌ No emoji in formal decks
- ❌ No more than 6 words per slide title
- ❌ No stock photos of fake handshakes or people pointing at laptops
